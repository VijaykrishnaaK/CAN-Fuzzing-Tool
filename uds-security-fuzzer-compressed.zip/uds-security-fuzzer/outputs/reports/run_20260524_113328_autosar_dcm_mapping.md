## AUTOSAR DCM Service Mapping

| UDS SID | Service Name | AUTOSAR Function | Config Container |
|---------|-------------|-----------------|-----------------|
| 0x10 | DiagnosticSessionControl | `Dcm_DiagnosticSessionControl()` | `DcmDspSession` |
| 0x11 | ECUReset | `Dcm_ResetECU()` | `DcmDspReset` |
| 0x27 | SecurityAccess | `Dcm_SecurityAccess()` | `DcmDspSecurity` |
| 0x28 | CommunicationControl | `Dcm_CommunicationControl()` | `DcmDspComControl` |
| 0x22 | ReadDataByIdentifier | `Dcm_ReadDataByIdentifier()` | `DcmDspData / DcmDspDataInfo` |
| 0x2E | WriteDataByIdentifier | `Dcm_WriteDataByIdentifier()` | `DcmDspData / DcmDspDataInfo` |
| 0x31 | RoutineControl | `Dcm_RoutineControl()` | `DcmDspRoutine` |
| 0x19 | ReadDTCInformation | `Dcm_ReadDtcInformation()` | `DcmDspReadDtcInformation` |
| 0x23 | ReadMemoryByAddress | `Dcm_ReadMemoryByAddress()` | `DcmDspMemory / DcmDspReadMemoryRange` |

## AUTOSAR Security Architecture

### SecOC — Secure Onboard Communication
**Module**: `AUTOSAR SecOC (AUTOSAR_SWS_SecureOnboardCommunication)`

Adds MAC (Message Authentication Code) to CAN/Ethernet messages. Prevents message injection — each frame is authenticated with a shared key and freshness counter. Countermeasure for CAN injection attacks your fuzzer simulates.

**DCM Interaction**: SecOC keys provisioned via DCM SID 0x2E (WDBI) in programming session. Key provisioning requires SA 0x27 unlock + programming session.

**Key Config**: `SecOCTxPduProcessing, SecOCRxPduProcessing, SecOCFreshnessValueId`

### CryIf — Crypto Interface
**Module**: `AUTOSAR CryIf + Crypto Driver`

Abstraction layer between DCM/SecOC and hardware crypto (HSM). Dcm_GetSeed() should call CryIf_RandomGenerate() → HSM RNG instead of software RNG → prevents predictable seeds.

**DCM Interaction**: Called by Dcm_GetSeed() for secure seed generation

**Key Config**: `CryIfKey, CryIfKeyElement, CryIfChannel`

### HSM — Hardware Security Module
**Module**: `SHE (Secure Hardware Extension) or SHE+`

Dedicated security processor on the MCU. Stores cryptographic keys in hardware — cannot be read via software. Performs AES encryption, MAC generation, RNG in hardware. Dcm_CompareKey() using HSM is constant-time by hardware design → eliminates timing oracle vulnerability.

**DCM Interaction**: Dcm_GetSeed() → CryIf → HSM RNG
Dcm_CompareKey() → CryIf → HSM AES-CMAC verify

**Key Config**: `HsmKeySlot, HsmKeyId, HsmChannel`
